package datamanagement;

public interface IUnitLister {

    public void clearUnits();
    public void addUnit(IUnit unit);

}
